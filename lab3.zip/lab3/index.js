import express from 'express';
import employeeRouters from './routes/employees.js';

const app = express();

app.use(express.json());

app.use('/employees', employeeRouters);

const PORT = 3000;
app.listen(PORT, () => {
  console.log('The Server is up and running at localhost:3000');
});
