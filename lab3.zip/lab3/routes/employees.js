import fs from 'node:fs';

import path from 'node:path';
import {fileURLToPath} from 'node:url';
import express from 'express';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const Router = express.Router();

const filePath = path.join(__dirname, '..', '..', 'lab1', 'data', 'data.json');
const dataJSON = fs.readFileSync(filePath, 'utf-8');
const dataParsed = JSON.parse(dataJSON);

Router.get('/', (_, res) => {
  // home/ahmedessam3270/ITI_nodejs/lab3/routes
  res.setHeader('Content-Type', 'application/json');
  res.status(200).send(dataJSON);
});

Router.get('/:id', (req, res) => {
  const foundEmloyee = dataParsed.find((emp) => emp.id === +req.params.id);
  if (!foundEmloyee) {
    res.status(404).json({message: 'Employee Not found'});
  }
  res.send(foundEmloyee);
});

Router.delete('/:id', (req, res) => {
  const employeesWithoutThisOne = dataParsed.filter((emp) => emp.id !== +req.params.id);
  res.json(employeesWithoutThisOne);
});

export default Router;
